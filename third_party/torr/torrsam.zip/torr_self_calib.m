%	By Philip Torr 2002
%	copyright Microsoft Corp.
%this function allows for self calibration


function f = torr_self_calib_f(x1,y1,x2,y2, no_matches,m3)