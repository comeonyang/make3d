


There are some 79 or so Matlab files here which will help in many aspects of the computer vision structure from motion problem, a full description is provided in the manual, torrsam.ps.

This beta is version 1, and it is my hope to greatly expand the scope of the thing for version 2.

Regards

Philip Torr
 

Microsoft Research Limited
7 JJ Thomson Avenue,
Cambridge CB3 0FB, UK.

Telephone:	+44 1223 479 700
Direct dial:	+44 1223 479 843
Fax:		+44 1223 479 999
http://www.research.microsoft.com
philtorr@microsoft.com
24 May, 2002

Registered Office:
Microsoft Limited
Microsoft Campus
Thames Valley Park
Reading RG6 1WG


Registered in England no. 03369488
VAT No. GB 642353552

